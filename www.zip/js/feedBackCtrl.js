angular.module('starter')

.controller('feedBackCtrl', function($scope) {


});



