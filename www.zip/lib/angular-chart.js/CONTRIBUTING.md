### Contributing

1. Create an issue
1. Fork the repo
1. Install dependencies: `npm install` and `bower install`
1. Make your changes
1. Install [GraphicsMagick](http://www.graphicsmagick.org/)
1. Run linter and tests: `gulp check`
1. Submit pull request
